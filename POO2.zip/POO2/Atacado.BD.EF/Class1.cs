﻿namespace Atacado.BD.EF;
public class Class1
{

}

﻿namespace Atacado.Poco;
public class Class1
{

}

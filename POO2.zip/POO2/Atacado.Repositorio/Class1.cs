﻿namespace Atacado.Repositorio;
public class Class1
{

}

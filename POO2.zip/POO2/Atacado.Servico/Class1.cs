﻿namespace Atacado.Servico;
public class Class1
{

}

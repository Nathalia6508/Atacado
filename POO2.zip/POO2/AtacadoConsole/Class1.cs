﻿namespace AtacadoConsole;
public class Class1
{

}
